# Swagger Play Framework Module

## Overview
This is a project to add swagger to play-framework; an implementation of the Swagger spec.  
You can find out more about both the spec and the framework at http://swagger.wordnik.com.  
For more information about Wordnik's APIs, please visit http://developer.wordnik.com.  

(This is for Play 1.2.x. If you're working with Play 2.0 Beta, please look at https://github.com/ayush/swagger-play2)
